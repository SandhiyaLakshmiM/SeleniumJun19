package week3.day1;

public class MyCar {
public static void main(String[] args) {
	Nano nanoCar = new Nano();
	nanoCar.applyBrake();
	nanoCar.changingGear();
	nanoCar.soundSystem();
	
	BMW bmwCar = new BMW();
	bmwCar.applyBrake();
}
}












