package week3.day1;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class ImplementedClass implements LearnInteface {

	public void test() {
		// TODO Auto-generated method stub
		System.out.println("test");
	}

	public static void main(String[] args) {
		LearnInteface obj = new ImplementedClass();
		obj.test();
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
