package week3.day1;

public class Calculator {
	public static void main(String[] args) {
		Calculator cal = new Calculator();
		
	}
	
	public void add(int a, int b) {
		System.out.println("Sum of two nos "+(a+b));
	}
	public void add(int a,int b,int c) {
		System.out.println("Sum of three nos"+(a+b+c));
	}
	public void add(float a, float b) {
		System.out.println("Sum of two float"+(a+b));
	}
}
