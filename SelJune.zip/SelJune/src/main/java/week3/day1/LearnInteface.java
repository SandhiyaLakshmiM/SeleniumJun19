package week3.day1;

public interface LearnInteface {
	public int num=1;
	public void test();
}
