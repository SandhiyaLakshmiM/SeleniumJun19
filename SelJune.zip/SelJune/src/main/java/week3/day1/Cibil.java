package week3.day1;

public interface Cibil {
	public void getCibilScore();
}
