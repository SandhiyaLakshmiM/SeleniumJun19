package week3.day1;

public abstract class LearnAbstract {
	
	public abstract void display() ;
	public void makeCall() {
		System.out.println("Make call - Abstract class");
	}

}
