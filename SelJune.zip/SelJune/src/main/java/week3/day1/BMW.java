package week3.day1;

public class BMW extends Car{
	//@Override
	/*public void applyBrake() {
		System.out.println("ABS Brake - BMW");
	}*/

}
