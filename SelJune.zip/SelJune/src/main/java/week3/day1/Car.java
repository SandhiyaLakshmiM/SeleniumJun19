package week3.day1;

public class Car extends Vechicle{
	
	final int num =10;
	public final void applyBrake() {
		System.out.println("Apply Brake - Car");
	}
	
	public void changingGear() {
		System.out.println("Change Gear - Car");
	}

}
