package week3.day1;

public interface RBI {
	public void rateOfInterest();
	public void minBalance();
}
