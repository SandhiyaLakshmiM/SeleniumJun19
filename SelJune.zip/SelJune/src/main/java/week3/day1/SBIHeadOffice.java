package week3.day1;

public abstract class SBIHeadOffice implements RBI, Cibil{
	public void rateOfInterest() {
		System.out.println("Interest rate");
	}
	public void getCibilScore() {
		System.out.println("Cibil score");
	}
}
