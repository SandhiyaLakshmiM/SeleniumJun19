package week3.day1;

public class Vechicle {
	public void soundSystem() {
		System.out.println("Sound System - Vechicle");
	}
	
	public void soundHorn() {
		System.out.println("Sound Horn - Vechicle");
	}

}
