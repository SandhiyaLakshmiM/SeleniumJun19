package learn;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearnAlert {

	public static void main(String[] args) throws InterruptedException, IOException {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://leafground.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElementByXPath("//h5[text()='Alert']").click();
		Thread.sleep(1000);
		driver.findElementByXPath("//button[text()='Line Breaks?']").click();
		Thread.sleep(3000);
		
		Alert alert = driver.switchTo().alert();
		String alertText = alert.getText();
//		alert.sendKeys("Sam");
		Thread.sleep(4000);
		
		alert.accept();
		
		System.out.println(alertText);
//		Thread.sleep(3000);
		
		
		
		
		
		
		
		
		
		
		
		
		
//		driver.close();
		
	}

}
