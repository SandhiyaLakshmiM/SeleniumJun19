package learn;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;

public class WindowHandling {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.w3schools.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String title1 = driver.getTitle();
		System.out.println("Window 1: "+title1);
		driver.findElementByXPath("//a[@href='/html/tryit.asp?filename=tryhtml_default']").click();
		Set<String> win = driver.getWindowHandles();
		List<String> li = new ArrayList<>();
		li.addAll(win);
		driver.switchTo().window(li.get(1));
		String title2 = driver.getTitle();
		System.out.println("Window 2: "+title2);
		
	}

}
