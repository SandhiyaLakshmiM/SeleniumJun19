package week1.day1;

public class LearnDataType {

	public static void main(String[] args) {
		int a;
		for(a = 1; a < 10; a++) {
			System.out.println(a);
		}
//		System.out.println(a);
		
		
		
		
		/*int a = 30;
		int b = 20;
		if(a > b) {
			System.out.println(a+" is greater than "+b);
		}else if(){
			System.out.println(b+" is greater");
		}*/
		
		//		a = a+2;
		/*--a;
		System.out.println(--a);
		System.out.println(a);*/








		/*int b = 7;
		int c = 3;
		System.out.println(!((a < b) || (a > c)));
		 */









		/*short age = 127;
		long a = 11111111111L;
		float temp = 45.2f;
		char initial = 'K';*/
	}

}




