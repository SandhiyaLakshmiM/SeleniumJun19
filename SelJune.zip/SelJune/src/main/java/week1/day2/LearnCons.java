package week1.day2;

public class LearnCons {
	public static void main(String[] args) {
		LearnCons lc = new LearnCons();
		lc.display();
		int n =1;
		System.out.println(n);
		
	}
	
	int num;
	
	public LearnCons() {
		System.out.println("constructor");
	}

	public static void display() {
		
		System.out.println("display 1");
		
	}

}
