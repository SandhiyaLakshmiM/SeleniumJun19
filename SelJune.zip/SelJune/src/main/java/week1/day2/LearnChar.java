package week1.day2;

public class LearnChar {

	public static void main(String[] args) {
		String sentence = " this is day2 training ";
		String[] split = sentence.trim().split(" ");
		System.out.println(split.length);
		
		/*String name = "hcl (45345)";
//		String replace = name.replace("212", "");
		String replaceAll = 
			name.replaceAll("\\D", "");
		System.out.println(replaceAll);*/
		
		
		
		
		
		//String upperCase = name.toUpperCase();
		/*if (name.trim().endsWith("jee")) {
			System.out.println("matched");
		}else {
			System.out.println("does not match");
		}*/
		//int length = name.length();
		/*char charAt = name.charAt(name.length()-1);
		System.out.println(charAt);
		System.out.println(name.toUpperCase());
		System.out.println(name.toLowerCase());
		
		
*/
	}

}






