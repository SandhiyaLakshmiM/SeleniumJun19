package week1.day2;

public class LearnArrays {

	public static void main(String[] args) {
		String[] model = {"audi", "bmw", "nexa", "nano"};
		for(String m : model) {
			System.out.println(m);
		}
		/*for (int i = 0; i < model.length; i++) {
			System.out.println(model[i]);
		}*/
		
	}

}
