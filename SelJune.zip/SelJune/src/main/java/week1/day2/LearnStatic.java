package week1.day2;

public class LearnStatic {

	public static void main(String[] args) {
		display();
		LearnCons.display();
	}
	public static void display() {
		System.out.println("display");
		
	}


}
