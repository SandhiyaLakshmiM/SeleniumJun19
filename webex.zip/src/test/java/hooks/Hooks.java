package hooks;

import org.openqa.selenium.OutputType;

import cucumber.api.Scenario;
import cucumber.api.java.AfterStep;
import libraries.Annotations;

public class Hooks extends Annotations {

	@AfterStep
	public void afterSteps(Scenario sc) {
		byte[] screenshotAs = driver.getScreenshotAs(OutputType.BYTES);
		sc.embed(screenshotAs, "image/png");

	}

}
