package runner;

import cucumber.api.CucumberOptions;
import libraries.Annotations;

@CucumberOptions(

		features = { "src\\test\\java\\features\\CreateLead.feature" }, glue = { "hooks",
				"pages" }, monochrome = true, plugin = { "pretty", "html:reports" })

public class Runner extends Annotations {

}
