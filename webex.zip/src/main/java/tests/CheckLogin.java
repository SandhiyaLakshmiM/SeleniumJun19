package tests;

import org.openqa.selenium.NoSuchElementException;
import org.testng.annotations.Test;

import libraries.Annotations;
import pages.HomePage;
import pages.LoginPage;

public class CheckLogin extends Annotations {
	@Test(expectedExceptions = NoSuchElementException.class)
	public void run() {
		String verifySuccess = new LoginPage().enterUsername("Demosalesmanager").enterPassword("crmsfa").clickLogin()
				.verifySuccess("Welcome");

		new HomePage().displayUserText(verifySuccess);

		//
	}
}
