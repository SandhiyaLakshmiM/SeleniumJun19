package pages;

import org.openqa.selenium.By;

import cucumber.api.java.en.Then;
import libraries.Annotations;

public class HomePage extends Annotations {
	@Then("verify login is {string}")
	public String verifySuccess(String username) {
		String leadID = driver.findElement(By.tagName("h2")).getText();
		if (leadID.contains(username)) {
			System.out.println("Success");
		} else
			System.out.println("failed");

		return leadID;
	}

	public void displayUserText(String text) {
		System.out.println(text);

	}

}
