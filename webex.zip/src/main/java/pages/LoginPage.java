package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import libraries.Annotations;

public class LoginPage extends Annotations {
	public LoginPage() {
		PageFactory.initElements(driver, this);
	}

	@CacheLookup
	@FindBy(how = How.ID, using = "username")
	private WebElement eleUserName;

	@Given("Enter username as {string}")
	public LoginPage enterUsername(String un) {
//		driver.findElement(By.id("username")).sendKeys(un);
		eleUserName.sendKeys(un);
		return this;
	}

	@And("Enter password {string}")
	public LoginPage enterPassword(String pwd) {
		driver.findElement(By.id("password")).sendKeys(pwd);
		return this;
	}

	@Then("Click on login button")
	public HomePage clickLogin() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return new HomePage();
	}

}
